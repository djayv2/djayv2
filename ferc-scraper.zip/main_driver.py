#!/usr/bin/env python3
import runpy

if __name__ == "__main__":
    runpy.run_module(mod_name="main", run_name="__main__")